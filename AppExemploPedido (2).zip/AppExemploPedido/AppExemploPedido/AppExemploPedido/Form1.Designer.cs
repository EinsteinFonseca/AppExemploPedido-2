﻿namespace AppExemploPedido
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCadastrarPedido = new System.Windows.Forms.Button();
            this.btListarPedidos = new System.Windows.Forms.Button();
            this.btListarItens = new System.Windows.Forms.Button();
            this.btCosnultarPedidos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btCadastrarPedido
            // 
            this.btCadastrarPedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCadastrarPedido.Location = new System.Drawing.Point(32, 56);
            this.btCadastrarPedido.Name = "btCadastrarPedido";
            this.btCadastrarPedido.Size = new System.Drawing.Size(471, 29);
            this.btCadastrarPedido.TabIndex = 26;
            this.btCadastrarPedido.Text = "CADASTRAR PEDIDO";
            this.btCadastrarPedido.UseVisualStyleBackColor = true;
            this.btCadastrarPedido.Click += new System.EventHandler(this.btCadastrarPedido_Click);
            // 
            // btListarPedidos
            // 
            this.btListarPedidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btListarPedidos.Location = new System.Drawing.Point(32, 102);
            this.btListarPedidos.Name = "btListarPedidos";
            this.btListarPedidos.Size = new System.Drawing.Size(471, 29);
            this.btListarPedidos.TabIndex = 27;
            this.btListarPedidos.Text = "LISTAR N° PEDIDOS";
            this.btListarPedidos.UseVisualStyleBackColor = true;
            // 
            // btListarItens
            // 
            this.btListarItens.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btListarItens.Location = new System.Drawing.Point(32, 145);
            this.btListarItens.Name = "btListarItens";
            this.btListarItens.Size = new System.Drawing.Size(471, 29);
            this.btListarItens.TabIndex = 28;
            this.btListarItens.Text = "LISTAR ITENS DOS PEDIDOS";
            this.btListarItens.UseVisualStyleBackColor = true;
            // 
            // btCosnultarPedidos
            // 
            this.btCosnultarPedidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCosnultarPedidos.Location = new System.Drawing.Point(32, 188);
            this.btCosnultarPedidos.Name = "btCosnultarPedidos";
            this.btCosnultarPedidos.Size = new System.Drawing.Size(471, 29);
            this.btCosnultarPedidos.TabIndex = 29;
            this.btCosnultarPedidos.Text = "CONSULTAR PEDIDOS";
            this.btCosnultarPedidos.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 270);
            this.Controls.Add(this.btCosnultarPedidos);
            this.Controls.Add(this.btListarItens);
            this.Controls.Add(this.btListarPedidos);
            this.Controls.Add(this.btCadastrarPedido);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btCadastrarPedido;
        private System.Windows.Forms.Button btListarPedidos;
        private System.Windows.Forms.Button btListarItens;
        private System.Windows.Forms.Button btCosnultarPedidos;
    }
}

