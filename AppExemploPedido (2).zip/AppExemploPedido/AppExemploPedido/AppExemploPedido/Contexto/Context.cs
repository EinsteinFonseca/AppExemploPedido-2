﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploPedido.Models;

namespace AppExemploPedido.Contexto
{
    public static class Context
    {
        public static List <Pedido> ListaPedidos = new List <Pedido> ();
        public static List <Item> listaItens = new List <Item> ();  
    }
}
