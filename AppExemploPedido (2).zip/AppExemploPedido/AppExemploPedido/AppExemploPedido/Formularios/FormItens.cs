﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms;
using AppExemploPedido.Contexto;

namespace AppExemploPedido.Formularios
{
    public partial class FormItens : Form
    {
        public FormItens()
        {
            InitializeComponent();
            var listaItem = Context.ListaPedidos.ToList();
            dtItens.DataSource = listaItem.ToList();
        }

        private void dtItens_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
