﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploPedido.Contexto;
using AppExemploPedido.Models;


namespace AppExemploPedido.Formularios
{
    public partial class FormConsultaPedido : Form
    {
        List<Pedido> pedidos = new List<Pedido>();
        List<Item> itens = new List<Item>();
        int cont = 1;

        public FormConsultaPedido()
        {
            InitializeComponent();
            pedidos = Context.ListaPedidos.ToList();
            itens = Context.listaItens.ToList();
            cbPesquisa.DataSource = pedidos.ToList();
            cbPesquisa.DisplayMember = "NumeroPedido";
            cbPesquisa.SelectedIndex = -1;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbPesquisa.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var pedido = pedidos[linhaSelec];
                txtNumeroPedido.Text = pedido.ToString();
                txtNome.Text = pedido.ToString();
                txtCPF.Text = pedido.ToString();
                //masterd detalhes

                var itensDetalhe = itens.Where(i => i.IdPedido == pedido.Id).ToList();
                dtTabela.DataSource = itensDetalhe.ToList();
                var total = itensDetalhe.Sum(i => i.Total);
                txtTotal.Text = total.ToString();
            }
            cont++;
        }

        private void dtTabela_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
