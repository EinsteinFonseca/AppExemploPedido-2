﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploPedido.Models;
using AppExemploPedido.Contexto;

namespace AppExemploPedido.Formularios
{
        
    public partial class FormPedido : Form
    {
        public Pedido pedido = new Pedido();
        public Item Item {  get; set; }
        public List<Item> itens = new List<Item>();
        static int IdItem = 1;
        static int IdPedido = 1;

        public FormPedido()
        {
            InitializeComponent();
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            Item item = new Item();
            item.Id = IdItem;
            item.Descricao = txtProduto.Text;
            item.Quantidade = Convert.ToDouble(txtQuantidade.Text);
            item.PrecoUnit = Convert.ToDouble(txtPrecoUnit.Text);
            item.CalcularTotal();
            txtTotal.Text = item.Total.ToString("F2");
            Item = item;

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            itens.Add(Item);
            dtTabela.DataSource = itens.ToList();
            txtCpf.Clear();
            txtProduto.Clear();
            txtNome.Clear();
            txtNumeroPedido.Clear();
            txtQuantidade.Clear();
            txtTotal.Clear();
            txtPrecoUnit.Clear();
            txtNumeroPedido.Select();
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            Item.IdPedido = IdPedido;
            Item.Id = IdItem;
            itens.Add(Item);
            itens.Add(Item);
            IdItem++;
            dtTabela.DataSource = itens.ToList();
            txtCpf.Clear();
            txtProduto.Clear();
            txtNome.Clear();
            txtNumeroPedido.Clear();
            txtQuantidade.Clear();
            txtTotal.Clear();
            txtPrecoUnit.Clear();
            txtNumeroPedido.Select();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pedido = new Pedido();
            pedido.Id = IdPedido;
            pedido.NumeroPedido = Convert.ToInt32(txtNumeroPedido.Text);
            pedido.Nome = txtNome.Text;
            pedido.Cpf = txtCpf.Text;
            //com objetos pedidos preenchidos, vamos salvar
            Context.ListaPedidos.Add(pedido);

            Context.listaitens.AddRange(itens);
            MessageBox.Show("SALVO COM SUCESSO", "2°A INFO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            IdPedido++;//gerar o valor do id do proximo registro
            txtProduto.Clear();
            txtNome.Clear();
            txtNumeroPedido.Clear();
            txtQuantidade.Clear();
            txtTotal.Clear();
            txtPrecoUnit.Clear();
            txtNumeroPedido.Select();
            txtCpf.Clear();
            txtProduto.Clear();
            txtNome.Clear();
            txtNumeroPedido.Select();
            txtNumeroPedido.Select();
            itens.Clear();
            dtTabela.DataSource = itens.ToList();

        }
    }
}
